<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
      Schema::create('pelanggarans', function (Blueprint $table) {
        $table->id('id_pelanggaran');
        $table->unsignedBigInteger('nis');
        $table->foreign('nis')->references('nis')->on('siswas');
        $table->string('jenis_pelanggaran');
        $table->string('keterangan');
        $table->dateTime('tanggal')->default(now());
        $table->unsignedBigInteger('id_user');
        $table->foreign('id_user')->references('id_user')->on('users');
        $table->text('foto')->nullable();
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
      Schema::table('pelanggarans', function (Blueprint $table) {
        $table->dropForeign(['id_user']);
    });
      Schema::table('pelanggarans', function (Blueprint $table) {
        $table->dropForeign(['nis']);
    });
      Schema::dropIfExists('pelanggarans');
    }
};
