<?php

use App\Http\Controllers\API\AngkatanController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\PelanggaranController;
use App\Http\Controllers\API\RPLController;
use App\Http\Controllers\API\AllJurusanController;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\SiswaController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::controller(AuthController::class)->group(function () {
  Route::post('login', 'login');
  Route::post('register', 'register');
});

Route::middleware('auth:sanctum')->group(function () { 
  // Current Logged In User
  Route::get('current-user', [AuthController::class, 'currentUser']);

  // Current Logged In User
  Route::get('user', [AuthController::class, 'allUser']);

  // Logout
  Route::post('logout', [AuthController::class, 'logout']);

  // Angkatan
  Route::post('create-angkatan', [AngkatanController::class, 'createAngkatan']);
  Route::get('angkatan', [AngkatanController::class, 'showAllAngkatan']);

  // Siswa
  Route::post('create-siswa', [SiswaController::class, 'createSiswa']);
  Route::get('siswa', [SiswaController::class, 'showAllSiswa']);

  // Pelanggaran
  Route::post('create-pelanggaran', [PelanggaranController::class, 'createPelanggaran']);
  Route::get('pelanggarans', [PelanggaranController::class, 'getPelanggaran']);
  Route::get('pelanggarans/{id}', [PelanggaranController::class, 'getPelanggaran']);

  // IOP
  Route::get('pelanggaran/iop', [AllJurusanController::class, 'getAllIop']);

  // RPL
  Route::get('pelanggaran/rpl', [AllJurusanController::class, 'getAllRpl']);

  // SIJA
  Route::get('pelanggaran/sija', [AllJurusanController::class, 'getAllSija']);

  // TEK
  Route::get('pelanggaran/tek', [AllJurusanController::class, 'getAllTek']);

  // PSPT
  Route::get('pelanggaran/pspt', [AllJurusanController::class, 'getAllPspt']);

  // TOI
  Route::get('pelanggaran/toi', [AllJurusanController::class, 'getAllToi']);

  // TPTU
  Route::get('pelanggaran/tptu', [AllJurusanController::class, 'getAllTptu']);

  // MEKA
  Route::get('pelanggaran/meka', [AllJurusanController::class, 'getAllMeka']);

  // TEI
  Route::get('pelanggaran/tei', [AllJurusanController::class, 'getAllTei']);
});

Route::put('pelanggaran/{id}', [PelanggaranController::class, 'update']);
Route::delete('pelanggaran/{id}', [PelanggaranController::class, 'destroy']);

Route::put('/rpl/{id}', [RPLController::class, 'updaterpl']);
Route::delete('/rpl/{id}', [RPLController::class, 'destroyrpl']);

Route::put('/iop/{id}', [AllJurusanController::class, 'updateiop']);
Route::delete('/iop/{id}', [AllJurusanController::class, 'destroyiop']);

Route::put('/tptu/{id}', [AllJurusanController::class, 'updatetptu']);
Route::delete('/tptu/{id}', [AllJurusanController::class, 'destroytptu']);

Route::put('/sija/{id}', [AllJurusanController::class, 'updatesija']);
Route::delete('/sija/{id}', [AllJurusanController::class, 'destroysija']);

Route::put('/toi/{id}', [AllJurusanController::class, 'updatetoi']);
Route::delete('/toi/{id}', [AllJurusanController::class, 'destroytoi']);

Route::put('/tek/{id}', [AllJurusanController::class, 'updatetek']);
Route::delete('/tek/{id}', [AllJurusanController::class, 'destroytek']);

Route::put('/pspt/{id}', [AllJurusanController::class, 'updatepspt']);
Route::delete('/pspt/{id}', [AllJurusanController::class, 'destroypspt']);

Route::put('/tei/{id}', [AllJurusanController::class, 'updatetei']);
Route::delete('/tei/{id}', [AllJurusanController::class, 'destroytei']);