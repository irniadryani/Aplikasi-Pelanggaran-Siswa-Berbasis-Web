<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Angkatan extends Model
{
    use HasFactory;

    protected $table        = 'angkatans';
    protected $primaryKey   = 'angkatan';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['angkatan', 'tahun_ajaran'];
    protected $hidden = [
      'created_at',
      'updated_at',
  ];
}
