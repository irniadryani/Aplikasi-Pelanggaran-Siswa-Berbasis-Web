<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TPTU extends Model
{
    use HasFactory;

    protected $table        = 'pelanggarans';
    protected $primaryKey   = 'id_pelanggaran';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['nis', 'jenis_pelanggaran', 'keterangan', 'id_user', 'foto'];
    protected $hidden = [
      'created_at',
      'updated_at',
  ];

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'nis', 'nis');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }
}
