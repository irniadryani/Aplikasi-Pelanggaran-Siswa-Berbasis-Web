<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    use HasFactory;
    
    protected $table        = 'siswas';
    protected $primaryKey   = 'nis';
    protected $keyType      = 'string';
    public $incrementing    = false;
    protected $fillable     = ['nis', 'nama', 'kelas', 'jurusan', 'angkatan', 'foto'];
    protected $hidden = [
      'created_at',
      'updated_at',
  ];

    public function pelanggaran()
    {
        return $this->hasMany(Pelanggaran::class, 'nis', 'nis');
    }

    public function angkatan()
    {
        return $this->belongsTo(Angkatan::class, 'angkatan', 'angkatan');
    }

}
