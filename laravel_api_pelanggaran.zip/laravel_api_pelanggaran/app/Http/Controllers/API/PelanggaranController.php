<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\PelanggaranRequest;
use App\Models\Pelanggaran;
use Exception;
use Illuminate\Http\Request;

class PelanggaranController extends Controller
{
    function getPelanggaran($id = null)
    {
        if (isset($id)) {
            $pelanggaran = Pelanggaran::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
            ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
            ->where('pelanggarans.id_pelanggaran', $id)
            ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
            ->get();
            return response()->json(['msg' => 'Data retrieved', 'data' => $pelanggaran], 200);
        } else {
            $pelanggaran = Pelanggaran::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
            ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
            ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
            ->get();
            return response()->json(['msg' => 'Data retrieved', 'data' => $pelanggaran], 200);
        }
    }

    function createPelanggaran(PelanggaranRequest $request)
    {
      try {
        $pelanggaran = Pelanggaran::create($request->all());

        // Load the related user and siswa data using eager loading
        $pelanggaran->load(['user', 'siswa']);

        return response()->json(['msg' => 'Data created', 'data' => $pelanggaran], 201);
    } catch (Exception $e) {
        return response()->json(['error' => 'Server error', 'message' => $e->getMessage()], 500);
    }
    }

    function update($id, PelanggaranRequest $request)
    {
        $pelanggaran = Pelanggaran::findOrFail($id);
        $pelanggaran->update($request->all());
        return response()->json(['msg' => 'Data updated', 'data' => $pelanggaran], 200);
    }

    function destroy($id)
    {
        $pelanggaran = Pelanggaran::findOrFail($id);
        $pelanggaran->delete();
        return response()->json(['msg' => 'Data deleted'], 200);
    }
}
