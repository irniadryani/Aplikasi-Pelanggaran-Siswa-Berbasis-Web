<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\AllJurusanRequest;
use App\Models\IOP;
use App\Models\MEKA;
use App\Models\TPTU;
use App\Models\SIJA;
use App\Models\TEK;
use App\Models\TOI;
use App\Models\PSPT;
use App\Models\RPL;
use App\Models\TEI;
use App\Models\Siswa;
use App\Models\Userr;
use Illuminate\Http\Request;

class AllJurusanController extends Controller
{

    // RPL
    public function getAllRpl()
    {
      $rpl = RPL::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Rekayasa Perangkat Lunak')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $rpl], 200);
    }

        public function store(RPLRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            RPL::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $rpl], 200);
        }
    
        public function updaterpl(Request $request, $id)
        {
            $rpl = RPL::find($id);
        
            if (!$rpl) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $rpl->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroyrpl($id)
        {
            $rpl = RPL::find($id);

            if (!$rpl) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }

    // IOP
    public function getAllIop()
    {
      $iop = IOP::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Instrumentasi dan Otomatisasi Proses')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $iop], 200);
    }

        public function storeiop(AllJurusanRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            IOP::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $iop], 200);
        }
    
        public function updateiop(Request $request, $id)
        {
            $iop = IOP::find($id);
        
            if (!$iop) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $iop->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroyiop($id)
        {
            $iop = IOP::find($id);

            if (!$iop) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


    //Controller Mekatronika
    public function getAllMeka()
    {
      $meka = MEKA::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Mekatronika')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
        return response()->json(['msg' => 'Data retrieved', 'data' => $meka], 200);
    }

        public function storemeka(AllJurusanRequest $request)
        {
            // Data yang telah validasi
            $validatedData = $request->validated();
        
            // Simpan data ke dalam database
            MEKA::create($validatedData);
        
            // Respon sukses atau lainnya
            return response()->json(['msg' => 'Data updated', 'data' => $MEKA], 200);
        }
    
        public function updatemeka(Request $request, $id)
        {
            $meka = MEKA::find($id);
        
            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $meka->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroymeka($id)
        {
            $meka = MEKA::find($id);

            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }




    //Controller TPTU
    public function getAllTptu()
    {
      $tptu = TPTU::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Teknik Pendingin dan Tata Udara')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $tptu], 200);
    }

        public function storetptu(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TPTU::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TPTU], 200);
        }
    
        public function updatetptu(Request $request, $id)
        {
            $tptu = MEKA::find($id);
        
            if (!$meka) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tptu->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytptu($id)
        {
            $tptu = TPTU::find($id);

            if (!$tptu) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


    //Controller SIJA
    public function getAllSija()
    {
      $sija = SIJA::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Sistem Jaringan dan Aplikasi')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $sija], 200);
    }

        public function storesija(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            SIJA::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $SIJA], 200);
        }
    
        public function updatesija(Request $request, $id)
        {
            $sija = SIJA::find($id);
        
            if (!$sija) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $sija->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroysija($id)
        {
            $sija = SIJA::find($id);

            if (!$sija) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


    //Controller TEK
    public function getAllTek()
    {
      $tek = TEK::join('siswas', 'pelanggaran.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Teknik Elektronika Komunikasi')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $tek], 200);
    }

        public function storetek(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TEK::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TEK], 200);
        }
    
        public function updatetek(Request $request, $id)
        {
            $tek = TEK::find($id);
        
            if (!$tek) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tek->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytek($id)
        {
            $tek = TEK::find($id);

            if (!$tek) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }
        

    //Controller TOI
    public function getAllToi()
    {
      $toi = TOI::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Teknik Otomasi Industri')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $toi], 200);
    }

        public function storetoi(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TOI::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TOI], 200);
        }
    
        public function updatetoi(Request $request, $id)
        {
            $toi = TOIO::find($id);
        
            if (!$toi) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $toi->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytoi($id)
        {
            $toi = TOI::find($id);

            if (!$toi) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }


    //Controller PSPT
    public function getAllPspt()
    {
      $pspt = PSPT::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Produk Siaran Program Televisi')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $pspt], 200);
    }

        public function storepspt(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            PSPT::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $PSPT], 200);
        }
    
        public function updatepspt(Request $request, $id)
        {
            $pspt = PSPT::find($id);
        
            if (!$pspt) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pspt->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroypspt($id)
        {
            $pspt = PSPT::find($id);

            if (!$pspt) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }

    //Controller TEI
    public function getAllTei()
    {
      $tei = TEI::join('siswas', 'pelanggarans.nis', '=', 'siswas.nis')
        ->join('users', 'pelanggarans.id_user', '=', 'users.id_user')
        ->where('siswas.jurusan', 'Teknik Elektronika Industri')
        ->select('siswas.nama as nama_siswa', 'siswas.kelas', 'siswas.angkatan', 'siswas.jurusan', 'users.name as nama_pendata', 'pelanggarans.*')
        ->get();
    
      return response()->json(['msg' => 'Data retrieved', 'data' => $tei], 200);
    }

        public function storetei(AllJurusanRequest $request)
        {
            $validatedData = $request->validated();
            TEI::create($validatedData);

            return response()->json(['msg' => 'Data updated', 'data' => $TEI], 200);
        }
    
        public function updatetei(Request $request, $id)
        {
            $tei = TEI::find($id);
        
            if (!$tei) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $tei->update($request->all());

            return response()->json(['message' => 'Pelanggaran berhasil diperbarui']);
        }

        public function destroytei($id)
        {
            $tei = TEI::find($id);

            if (!$tei) {
                return response()->json(['message' => 'Pelanggaran tidak ditemukan'], 404);
            }

            $pelanggaran->delete();

            return response()->json(['message' => 'Pelanggaran berhasil dihapus']);
        }
}






