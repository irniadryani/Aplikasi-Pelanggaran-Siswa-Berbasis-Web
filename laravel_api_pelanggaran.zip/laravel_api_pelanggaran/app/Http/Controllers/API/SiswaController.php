<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\SiswaRequest;
use App\Models\Siswa;
use Illuminate\Http\Request;

class SiswaController extends Controller
{
  function createSiswa(SiswaRequest $request)
  {
      $siswa = Siswa::create($request->all());
      $siswa->load('angkatan');
      return response()->json(['msg' => 'Data created', 'data' => $siswa], 201);
  }

  function showAllSiswa()
  {
    $siswa = Siswa::get();
    $siswa->load('angkatan');
    return response()->json(['msg' => 'Data retrieved', 'data' => $siswa], 200);
  }
}
