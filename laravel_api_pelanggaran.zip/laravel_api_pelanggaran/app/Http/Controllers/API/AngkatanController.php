<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\AngkatanRequest;
use App\Models\Angkatan;
use Illuminate\Http\Request;

class AngkatanController extends Controller
{

  function createAngkatan(AngkatanRequest $request)
  {
      $angkatan = Angkatan::create($request->all());
      return response()->json(['msg' => 'Data created', 'data' => $angkatan], 201);
  }

  function showAllAngkatan()
  {
    $angkatan = Angkatan::get();
    return response()->json(['msg' => 'Data retrieved', 'data' => $angkatan], 200);
  }
}
